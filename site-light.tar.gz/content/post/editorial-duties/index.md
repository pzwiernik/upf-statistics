---
reading_time: false
title: New editorial duties
subtitle: ""
date: 2024-09-01T01:00:00.000Z
draft: false
authors: false
profile: false
featured: false
image:
  filename: ""
  focal_point: Smart
  preview_only: false
---
David Rossell started serving on Sep 2024 as co-editor at the journal [Bayesian Analysis](https://projecteuclid.org/journals/bayesian-analysis)
