---
title: Keynote talk at BAYSM 2023
date: 2023-02-01T01:01:00.000Z
draft: false
featured: false
profile: false
reading_time: false
authors: false
image:
  filename: download-5-.jpeg
  focal_point: Smart
  preview_only: false
---
David Rossell will give a keynote talk at the [BAYSM meeting](https://events.stat.uconn.edu/BAYSM2023/) organized by the junior section of International Society for Bayesian Analysis
