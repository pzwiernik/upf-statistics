---
reading_time: false
title: David Rossell in ISBA Board of directors
date: 2024-09-01T23:01:00.000Z
draft: false
profile: false
featured: false
authors: false
image:
  filename: ""
  focal_point: Smart
  preview_only: false
---
David Rossell has been elected for the Board of Directors at [ISBA.](https://bayesian.org/)
