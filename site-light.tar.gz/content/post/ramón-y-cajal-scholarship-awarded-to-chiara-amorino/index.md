---
title: Ramón y Cajal Scholarship awarded to Chiara Amorino
date: 2025-06-19T07:37:00.000+02:00
draft: false
authors: false
reading_time: false
featured: false
image:
  filename: featured
  focal_point: Smart
  preview_only: false
---
Congratulations to Chiara for obtaining the Ramón y Cajal grant. The Ramón y Cajal 5-year tenure track contract (RyC) is funded by the [Spanish Ministry of Science](https://en.wikipedia.org/wiki/Ministry_of_Science_(Spain)), that allows outstanding mid-career researchers in foreign countries to establish themselves in Spanish research institutions.[](https://en.wikipedia.org/wiki/Ram%C3%B3n_y_Cajal_(scholarship)#cite_note-:0-1) It is the most prestigious nationally-funded research contract to follow a scientific career in Spain.
