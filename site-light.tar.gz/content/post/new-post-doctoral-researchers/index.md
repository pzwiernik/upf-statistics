---
reading_time: false
title: New post-doctoral researchers
date: 2024-07-11T01:00:00.000Z
draft: false
authors: false
profile: false
featured: false
image:
  filename: ""
  focal_point: Smart
  preview_only: false
---
Jack Carter and Elena Bortolato are joining the group in Sep 2024 to do a post-doc in themes related to graphical models, Bayesian inference, latent variables and data integration. Jack is funded by a competitive [Eutopia fellowship](https://eutopia-university.eu/english-version/sif-post-doctoral-fellowships), and Elena by an ERC grant from Prof. Stephen Hansen at UCL.
