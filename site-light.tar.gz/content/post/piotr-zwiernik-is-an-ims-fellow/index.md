---
title: Piotr Zwiernik is an IMS fellow
date: 2024-04-01T01:00:00.000Z
draft: false
featured: false
profile: false
reading_time: false
authors: false
image:
  filename: download.jpeg
  focal_point: Smart
  preview_only: false
---
Congratulations to Piotr who is in the 2024 class of IMS Fellows. Piotr has been elected  "*For outstanding contributions to the theory of graphical models, exponential families, multivariate positive dependence, and dedicated editorial and organizational service to the profession*." See [here.](https://imstat.org/2024/05/17/2024-ims-fellows-announced/)
