---
title: ERC Starting Grant 2021 awarded to Geert Mesters
subtitle: ""
date: 2022-02-02T02:02:00.000Z
draft: false
profile: false
featured: false
reading_time: false
authors: false
image:
  filename: download-1-.png
  focal_point: Smart
  preview_only: false
---
The European Research Council (ERC) has awarded a Starting Grant to our colleague Geert Mesters. In his ERC project, Geert will conduct research on Econometrics for Macroeconomic Policy Evaluation.
