---
title: 'Conference on "Mathematics Aspects of Learning - 20 years later" '
date: 2024-05-01T01:00:00.000Z
draft: false
authors: false
profile: false
reading_time: false
featured: false
image:
  filename: download-1-.jpeg
  focal_point: Smart
  preview_only: false
---
Gabor, Luc, and others are organizing a fantastic workshop in Barcelona at the Centro de Recerca Matemàtica (Casa Convalescència) from September 9 to September 13, 2024. Terrific line-up of speakers, Piotr and Gergely will be giving talks, and many of us will be there. For more details, please visit [this link](https://www.crm.cat/mathematical-aspects-of-learning-theory/).
