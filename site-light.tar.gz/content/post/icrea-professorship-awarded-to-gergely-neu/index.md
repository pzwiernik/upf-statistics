---
reading_time: false
title: ICREA Professorship awarded to Gergely Neu
date: 2025-07-09T02:28:00.000Z
draft: false
authors: false
profile: false
featured: false
image:
  filename: ""
  focal_point: Smart
  preview_only: true
---
Gergely Neu has become one of the new ICREA Professors. This is a permanent, tenured positions to researchers from all over the world to come and work in Catalonia. Over the years these positions have become a synonym of global academic excellence. Congratulations Gergő!!!
