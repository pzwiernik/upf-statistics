---
title: Plenary talk and student award at ICSDS 2023
subtitle: ""
date: 2023-09-01T01:01:00.000Z
draft: false
profile: false
featured: false
reading_time: false
authors: false
image:
  filename: download-4-.jpeg
  focal_point: Smart
  preview_only: false
---
Gábor Lugosi will give a plenary talk at [International Conference on Data Science (ICSDS) 2023 meeting](https://sites.google.com/view/icsds2023).

PhD student Paul Rognon received a student award also at the ICSDS, which features a monetary prize given at an award ceremony
