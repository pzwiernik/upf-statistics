---
title: Gábor elected to the Institute of Mathematical Statistics (IMS) council
subtitle: ""
date: 2023-03-03T01:01:00.000Z
draft: false
profile: false
featured: false
reading_time: false
authors: false
image:
  filename: download.jpeg
  focal_point: Smart
  preview_only: false
---
Gábor Lugosi was elected to the new IMS council after the 2023 elections. He will be in the council up until 2026.
