---
title: "Vicenç Gómez"
first_name: Vicenç
last_name: Gómez
role: Associate Professor (Affiliated)
organizations:
  - name: Universitat Pompeu Fabra
    url: "https://www.upf.edu/web/ai/vicenc-gomez"
interests:
  - Machine learning
  - Artificial intelligence
  - Optimal control
  - Complex networks
user_groups:
  - Affiliated
---