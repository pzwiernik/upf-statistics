---
title: "Michael Greenacre"
first_name: Michael
last_name: Greenacre
role: Emeritus Professor
organizations:
  - name: Universitat Pompeu Fabra
    url: "https://www.upf.edu/web/econ/people/michael-greenacre"
interests:
  - Multivariate analysis
  - Correspondence analysis
  - Compositional data analysis
  - Data visualization
social:
  - icon: globe
    icon_pack: fas
    link: "https://www.upf.edu/en/web/cres/investigadors-associats/-/asset_publisher/hPWH34g7unc2/content/michael-greenacre/maximized"
user_groups:
  - Emeritus
---