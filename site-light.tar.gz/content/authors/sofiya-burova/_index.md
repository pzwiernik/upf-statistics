---
title: "Sofiya Burova"
first_name: Sofiya
last_name: Burova
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---