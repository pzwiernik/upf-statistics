---
title: "Maxim Fedotov"
first_name: Maxim
last_name: Fedotov
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---