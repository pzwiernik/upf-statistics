---
title: "Georgios Nikolaos Karelas"
first_name: Georgios Nikolaos
last_name: Karelas
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---