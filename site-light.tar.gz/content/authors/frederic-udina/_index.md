---
title: "Frederic Udina"
first_name: Frederic
last_name: Udina
role: Emeritus Professor
organizations:
  - name: Universitat Pompeu Fabra
    url: "https://pascal.upf.edu/~frederic.udina"
interests:
  - Applied statistics
  - Non‑parametric curve estimation
  - Computational statistics
  - Public statistics
social:
  - icon: globe
    icon_pack: fas
    link: "https://pascal.upf.edu/~frederic.udina"
user_groups:
  - Emeritus
---