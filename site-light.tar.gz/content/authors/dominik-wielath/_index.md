---
title: "Dominik Wielath"
first_name: Dominik
last_name: Wielath
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---