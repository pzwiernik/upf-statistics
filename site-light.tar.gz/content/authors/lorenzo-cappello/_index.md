---
title: "Lorenzo Cappello"
first_name: Lorenzo
last_name: Cappello
role: Ramón y Cajal Fellow
organizations:
  - name: Universitat Pompeu Fabra
    url: "https://lorenzocapp.github.io/"
interests:
  - Bayesian inference
  - Computational methods
  - Non‑parametric statistics
  - Applied statistical models
social:
  - icon: globe
    icon_pack: fas
    link: "https://lorenzocapp.github.io/"
  - icon: google-scholar
    icon_pack: ai
    link: "https://scholar.google.com/citations?user=A9Oxv3UAAAAJ"
user_groups:
  - Principal Investigators
---

