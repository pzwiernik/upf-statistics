---
title: "Robert Castelo"
first_name: Robert
last_name: Castelo
role: Professor (Affiliated)
organizations:
  - name: Universitat Pompeu Fabra
    url: "https://functionalgenomics.upf.edu/"
interests:
  - Computational biology
  - High‑dimensional omics data
  - Graphical models
user_groups:
  - Affiliated
---