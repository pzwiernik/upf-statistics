---
title: "Paul Rognon Vael"
first_name: Paul
last_name: Rognon Vael
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---