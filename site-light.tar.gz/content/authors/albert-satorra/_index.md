---
title: Albert Satorra
first_name: Albert
last_name: Satorra
role: Emeritus Professor
organizations:
  - name: Universitat Pompeu Fabra
    url: https://www.econ.upf.edu/~satorra/
interests:
  - Structural equation models
  - Longitudinal & panel data
  - Multivariate analysis
social:
  - icon: globe
    icon_pack: fas
    link: https://www.econ.upf.edu/~satorra/
user_groups:
  - Emeritus
---
