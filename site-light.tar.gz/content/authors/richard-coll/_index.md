---
title: "Richard Coll Josifov"
first_name: Richard 
last_name: Coll Josifov
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---