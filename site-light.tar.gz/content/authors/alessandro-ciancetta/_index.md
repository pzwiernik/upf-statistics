---
title: "Alessandro Ciancetta"
first_name: Alessandro
last_name: Ciancetta
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---