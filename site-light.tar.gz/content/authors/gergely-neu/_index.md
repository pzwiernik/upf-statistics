---
title: Gergely Neu
first_name: Gergely
last_name: Neu
role: ICREA Research Professor
interests:
  - Online optimization
  - Bandit problems
  - Reinforcement‑learning theory
organizations:
  - name: Universitat Pompeu Fabra
    url: https://cs.bme.hu/~gergo/
superuser: false
user_groups:
  - Principal Investigators
---
