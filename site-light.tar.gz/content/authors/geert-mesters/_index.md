---
title: "Geert Mesters"
first_name: Geert
last_name: Mesters
role: Associate Professor (Affiliated)
organizations:
  - name: Universitat Pompeu Fabra
    url: "https://www.geertmesters.com/"
interests:
  - Time‑series econometrics
  - Applied micro‑ and macro‑economics
user_groups:
  - Affiliated
---