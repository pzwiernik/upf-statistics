---
title: 'Inverse Q-Learning Done Right: Offline Imitation Learning in $Q^π$-Realizable
  MDPs'
date: '2025-05-26T13:10:27Z'
publishDate: '2025-05-26T13:10:27Z'
doi: ''
authors:
- Antoine Moulin
- Gergely Neu
- Luca Viano
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2505.19946v2
url_pdf: http://arxiv.org/pdf/2505.19946v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
