---
title: Multivariate Poisson approximation of joint subgraph counts in random graphs
  via size-biased couplings
date: '2025-01-19T21:44:08Z'
publishDate: '2025-01-19T21:44:08Z'
doi: ''
authors:
- Eulalia Nualart
- Rui-Ray Zhang
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2501.11180v2
url_pdf: http://arxiv.org/pdf/2501.11180v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
