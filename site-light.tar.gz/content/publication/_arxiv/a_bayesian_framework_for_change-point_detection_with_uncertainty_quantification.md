---
title: A Bayesian framework for change-point detection with uncertainty quantification
date: '2025-07-02T10:15:01Z'
publishDate: '2025-07-02T10:15:01Z'
doi: ''
authors:
- Davis Berlind
- Lorenzo Cappello
- Oscar Hernan Madrid Padilla
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2507.01558v2
url_pdf: http://arxiv.org/pdf/2507.01558v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
