---
title: 'Kinetic interacting particle system: parameter estimation from complete and
  partial discrete observations'
date: '2024-10-14T07:37:12Z'
publishDate: '2024-10-14T07:37:12Z'
doi: ''
authors:
- Chiara Amorino
- Vytautė Pilipauskaitė
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2410.10226v1
url_pdf: http://arxiv.org/pdf/2410.10226v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
