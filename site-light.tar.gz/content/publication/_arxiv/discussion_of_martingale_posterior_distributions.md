---
title: Discussion of Martingale Posterior Distributions
date: '2023-03-04T12:32:39Z'
publishDate: '2023-03-04T12:32:39Z'
doi: ''
authors:
- David Rossell
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2303.02403v1
url_pdf: http://arxiv.org/pdf/2303.02403v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
