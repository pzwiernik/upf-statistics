---
title: Detecting weighted hidden cliques
date: '2025-06-26T17:58:22Z'
publishDate: '2025-06-26T17:58:22Z'
doi: ''
authors:
- Urmisha Chatterjee
- Karissa Huang
- Ritabrata Karmakar
- B. R. Vinay Kumar
- Gábor Lugosi
- Nandan Malhotra
- Anirban Mandal
- Maruf Alam Tarafdar
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2506.21543v1
url_pdf: http://arxiv.org/pdf/2506.21543v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
