---
title: Distances for Markov chains from sample streams
date: '2025-05-23T15:09:04Z'
publishDate: '2025-05-23T15:09:04Z'
doi: ''
authors:
- Sergio Calo
- Anders Jonsson
- Gergely Neu
- Ludovic Schwartz
- Javier Segovia-Aguas
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2505.18005v1
url_pdf: http://arxiv.org/pdf/2505.18005v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
