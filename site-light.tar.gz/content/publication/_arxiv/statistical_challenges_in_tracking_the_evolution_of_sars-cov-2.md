---
title: Statistical Challenges in Tracking the Evolution of SARS-CoV-2
date: '2021-08-30T16:34:22Z'
publishDate: '2021-08-30T16:34:22Z'
doi: ''
authors:
- Lorenzo Cappello
- Jaehee Kim
- Sifan Liu
- Julia A. Palacios
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2108.13362v1
url_pdf: http://arxiv.org/pdf/2108.13362v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
