---
title: Bayesian variance change point detection with credible sets
date: '2022-11-25T13:29:03Z'
publishDate: '2022-11-25T13:29:03Z'
doi: ''
authors:
- Lorenzo Cappello
- Oscar Hernan Madrid Padilla
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2211.14097v3
url_pdf: http://arxiv.org/pdf/2211.14097v3
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
