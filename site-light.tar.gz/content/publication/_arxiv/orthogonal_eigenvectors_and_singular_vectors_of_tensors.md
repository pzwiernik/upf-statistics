---
title: Orthogonal eigenvectors and singular vectors of tensors
date: '2025-06-23T18:05:10Z'
publishDate: '2025-06-23T18:05:10Z'
doi: ''
authors:
- Alvaro Ribot
- Anna Seigal
- Piotr Zwiernik
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2506.19009v1
url_pdf: http://arxiv.org/pdf/2506.19009v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
