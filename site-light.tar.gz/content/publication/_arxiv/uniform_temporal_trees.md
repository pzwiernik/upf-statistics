---
title: Uniform temporal trees
date: '2025-01-22T17:51:26Z'
publishDate: '2025-01-22T17:51:26Z'
doi: ''
authors:
- Caelan Atamanchuk
- Luc Devroye
- Gabor Lugosi
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2501.13044v1
url_pdf: http://arxiv.org/pdf/2501.13044v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
