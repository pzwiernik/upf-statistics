---
title: Differential Machine Learning for Time Series Prediction
date: '2025-03-05T09:36:57Z'
publishDate: '2025-03-05T09:36:57Z'
doi: ''
authors:
- Akash Yadav
- Eulalia Nualart
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2503.03302v2
url_pdf: http://arxiv.org/pdf/2503.03302v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
