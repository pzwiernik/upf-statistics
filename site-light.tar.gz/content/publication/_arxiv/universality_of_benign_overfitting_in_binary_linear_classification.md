---
title: Universality of Benign Overfitting in Binary Linear Classification
date: '2025-01-17T20:22:06Z'
publishDate: '2025-01-17T20:22:06Z'
doi: ''
authors:
- Ichiro Hashimoto
- Stanislav Volgushev
- Piotr Zwiernik
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2501.10538v1
url_pdf: http://arxiv.org/pdf/2501.10538v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
