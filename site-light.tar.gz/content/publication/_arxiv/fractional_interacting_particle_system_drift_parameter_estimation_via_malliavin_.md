---
title: 'Fractional interacting particle system: drift parameter estimation via Malliavin
  calculus'
date: '2025-02-10T14:30:52Z'
publishDate: '2025-02-10T14:30:52Z'
doi: ''
authors:
- Chiara Amorino
- Ivan Nourdin
- Radomyra Shevchenko
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2502.06514v2
url_pdf: http://arxiv.org/pdf/2502.06514v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
