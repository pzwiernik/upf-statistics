---
title: Improving variable selection properties by leveraging external data
date: '2025-02-21T16:52:20Z'
publishDate: '2025-02-21T16:52:20Z'
doi: ''
authors:
- Paul Rognon-Vael
- David Rossell
- Piotr Zwiernik
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2502.15584v2
url_pdf: http://arxiv.org/pdf/2502.15584v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
