---
title: Nonparametric estimation of the stationary density for Hawkes-diffusion systems
  with known and unknown intensity
date: '2024-12-11T13:51:02Z'
publishDate: '2024-12-11T13:51:02Z'
doi: ''
authors:
- Chiara Amorino
- Charlotte Dion-Blanc
- Arnaud Gloter
- Sarah Lemler
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2412.08386v1
url_pdf: http://arxiv.org/pdf/2412.08386v1
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
