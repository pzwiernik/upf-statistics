---
title: Linear Bandits with Non-i.i.d. Noise
date: '2025-05-26T14:06:23Z'
publishDate: '2025-05-26T14:06:23Z'
doi: ''
authors:
- Baptiste Abélès
- Eugenio Clerico
- Hamish Flynn
- Gergely Neu
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2505.20017v2
url_pdf: http://arxiv.org/pdf/2505.20017v2
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
