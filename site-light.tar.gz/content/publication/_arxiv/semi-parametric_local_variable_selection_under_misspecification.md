---
title: Semi-parametric local variable selection under misspecification
date: '2023-11-14T17:24:38Z'
publishDate: '2023-11-14T17:24:38Z'
doi: ''
authors:
- David Rossell
- Arnold Kisuk Kseung
- Ignacio Saez
- Michele Guindani
publication: arXiv
publication_types:
- preprint
featured: false
publication_url: http://arxiv.org/abs/2401.10235v3
url_pdf: http://arxiv.org/pdf/2401.10235v3
generated: arxiv
abstract: ''
summary: ''
tags: []
categories: []
projects: []
---
