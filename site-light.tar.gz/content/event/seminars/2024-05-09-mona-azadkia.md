---
title: "Mona Azadkia (London School of Economics): A Simple Measure of Conditional Dependence"
abstract: ""
location: "24.S01"
date: 2024-05-09T00:00:00
date_end: 2024-05-09T00:00:00
all_day: false
event: Statistics Seminar
event_url: ""
publishDate: 2024-05-09T00:00:00
draft: false
featured: false
image:
  filename: "seminar.png"
  focal_point: Smart
  preview_only: false
---
