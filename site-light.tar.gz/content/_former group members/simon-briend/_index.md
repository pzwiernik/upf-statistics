---
title: "Simon Briend"
first_name: Simon
last_name: Briend
role: PhD Student
organizations:
  - name: Universitat Pompeu Fabra
user_groups:
  - Grad Students
---